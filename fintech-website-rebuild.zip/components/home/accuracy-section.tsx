"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, TrendingUp, Target, BarChart3, Activity } from "lucide-react"

interface AccuracyCardProps {
  plan: string
  accuracy: string
  description: string
  delay: number
  icon: React.ElementType
  color: string
}

function AccuracyCard({ plan, accuracy, description, delay, icon: Icon, color }: AccuracyCardProps) {
  const [displayValue, setDisplayValue] = useState(0)
  const targetValue = Number.parseInt(accuracy.split("-")[0].replace("+", "").replace("%", ""))

  useEffect(() => {
    const timer = setTimeout(() => {
      let start = 0
      const duration = 1500
      const increment = targetValue / (duration / 16)

      const animate = () => {
        start += increment
        if (start < targetValue) {
          setDisplayValue(Math.floor(start))
          requestAnimationFrame(animate)
        } else {
          setDisplayValue(targetValue)
        }
      }
      requestAnimationFrame(animate)
    }, delay)

    return () => clearTimeout(timer)
  }, [targetValue, delay])

  return (
    <Card className="relative overflow-hidden border-border/50 transition-all hover:border-accent/50 hover:shadow-lg group">
      <div className="absolute right-0 top-0 h-24 w-24 bg-accent/5" style={{ borderRadius: "0 0 0 100%" }} />
      <CardHeader className="pb-2">
        <div className="flex items-center gap-3">
          <div
            className={`flex h-10 w-10 items-center justify-center rounded-lg ${color} transition-transform group-hover:scale-110`}
          >
            <Icon className="h-5 w-5 text-white" />
          </div>
          <CardTitle className="text-lg font-medium">{plan}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-3">
          <span className="text-4xl font-bold text-accent">{displayValue}%</span>
          {accuracy.includes("+") && <span className="text-2xl font-bold text-accent">+</span>}
          {accuracy.includes("-") && <span className="text-lg text-muted-foreground"> - {accuracy.split("-")[1]}</span>}
        </div>
        <p className="text-sm text-muted-foreground">{description}</p>

        <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-1000"
            style={{ width: `${displayValue}%` }}
          />
        </div>

        <div className="mt-4 flex items-end justify-between h-12 gap-1">
          {[35, 55, 45, 70, 60, 80, 65, 85, 75, 90].map((h, i) => (
            <div
              key={i}
              className="flex-1 bg-gradient-to-t from-purple-500/30 to-blue-500/50 rounded-t transition-all duration-300 group-hover:from-purple-500/50 group-hover:to-blue-500/70"
              style={{ height: `${h}%` }}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export function AccuracySection() {
  const accuracyData = [
    {
      plan: "Monthly Plan",
      accuracy: "70-75%",
      description: "Short-term trading signals with weekly performance tracking",
      icon: Activity,
      color: "bg-purple-500",
    },
    {
      plan: "Quarterly Plan",
      accuracy: "75-80%",
      description: "Medium-term strategies with monthly performance reviews",
      icon: BarChart3,
      color: "bg-blue-500",
    },
    {
      plan: "Half-Yearly Plan",
      accuracy: "80-85%",
      description: "Long-term positioning with bi-monthly analysis reports",
      icon: TrendingUp,
      color: "bg-indigo-500",
    },
    {
      plan: "Yearly & Customized",
      accuracy: "88%+",
      description: "Premium strategies with dedicated relationship manager",
      icon: Target,
      color: "bg-violet-500",
    },
  ]

  return (
    <section id="accuracy" className="bg-muted/30 py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <span className="mb-4 inline-block text-sm font-medium text-accent">Performance</span>
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl text-balance">
            Our Track Record Speaks for Itself
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Transparent performance metrics across all our subscription plans. Our accuracy rates are calculated based
            on historical performance data.
          </p>
        </div>

        <div className="mx-auto grid max-w-5xl gap-6 md:grid-cols-2 lg:grid-cols-4">
          {accuracyData.map((data, index) => (
            <AccuracyCard key={index} {...data} delay={index * 200} />
          ))}
        </div>

        <div className="mx-auto mt-10 max-w-3xl">
          <div className="flex items-start gap-3 rounded-lg border border-warning/30 bg-warning/10 p-4">
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-warning" />
            <div>
              <h4 className="mb-1 font-semibold text-warning-foreground">Important Disclaimer</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Accuracy is indicative and based on historical performance. Markets are subject to risk and returns are
                not guaranteed. Past performance is not indicative of future results. Please read all scheme related
                documents carefully before investing.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
