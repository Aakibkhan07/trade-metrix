"use client"

import { CandlestickChart } from "@/components/charts/candlestick-chart"
import { LiveMarketTicker } from "@/components/charts/live-market-ticker"
import { TrendingUp, BarChart3, Activity, Zap } from "lucide-react"

export function LiveChartsSection() {
  return (
    <section className="py-24 bg-card relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
      <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-blue-500/5 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
            <Activity className="h-4 w-4 icon-glow" />
            Live Market Data
          </span>
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            Real-Time <span className="text-gradient">Candlestick Charts</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional-grade charts with live OHLC data, volume analysis, and pattern recognition
          </p>
        </div>

        {/* Live Ticker */}
        <div className="mb-12">
          <LiveMarketTicker />
        </div>

        {/* Chart Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <div className="glass rounded-xl p-4 border border-primary/20 hover-scale">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center icon-glow">
                <Zap className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">0.1s</p>
                <p className="text-xs text-muted-foreground">Chart Update</p>
              </div>
            </div>
          </div>
          <div className="glass rounded-xl p-4 border border-primary/20 hover-scale">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center icon-glow-blue">
                <BarChart3 className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">15+</p>
                <p className="text-xs text-muted-foreground">Chart Types</p>
              </div>
            </div>
          </div>
          <div className="glass rounded-xl p-4 border border-primary/20 hover-scale">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">100+</p>
                <p className="text-xs text-muted-foreground">Indicators</p>
              </div>
            </div>
          </div>
          <div className="glass rounded-xl p-4 border border-primary/20 hover-scale">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center">
                <Activity className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">24/7</p>
                <p className="text-xs text-muted-foreground">Monitoring</p>
              </div>
            </div>
          </div>
        </div>

        {/* Candlestick Charts Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          <CandlestickChart symbol="NIFTY" title="NIFTY 50" height={320} />
          <CandlestickChart symbol="BANKNIFTY" title="BANK NIFTY" height={320} />
        </div>

        {/* Additional Chart Features */}
        <div className="mt-12 glass rounded-2xl p-8 border border-primary/20">
          <h3 className="text-xl font-semibold text-foreground mb-6 text-center">Chart Features</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-xl bg-gradient-to-br from-purple-500/20 to-violet-600/20 flex items-center justify-center mb-3 animate-float">
                <svg
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <rect x="3" y="8" width="4" height="12" rx="1" />
                  <rect x="10" y="4" width="4" height="16" rx="1" />
                  <rect x="17" y="10" width="4" height="10" rx="1" />
                </svg>
              </div>
              <p className="font-medium text-foreground text-sm">Candlestick</p>
              <p className="text-xs text-muted-foreground">OHLC visualization</p>
            </div>
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-600/20 flex items-center justify-center mb-3 animate-float-delay">
                <svg
                  className="h-6 w-6 text-accent"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path d="M3 3v18h18" />
                  <path d="M21 9l-6 6-4-4-5 5" />
                </svg>
              </div>
              <p className="font-medium text-foreground text-sm">Line Charts</p>
              <p className="text-xs text-muted-foreground">Trend analysis</p>
            </div>
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-xl bg-gradient-to-br from-emerald-500/20 to-green-600/20 flex items-center justify-center mb-3 animate-float">
                <svg
                  className="h-6 w-6 text-green-500"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <rect x="3" y="12" width="4" height="8" rx="1" />
                  <rect x="10" y="8" width="4" height="12" rx="1" />
                  <rect x="17" y="4" width="4" height="16" rx="1" />
                </svg>
              </div>
              <p className="font-medium text-foreground text-sm">Volume Bars</p>
              <p className="text-xs text-muted-foreground">Market activity</p>
            </div>
            <div className="text-center">
              <div className="h-12 w-12 mx-auto rounded-xl bg-gradient-to-br from-orange-500/20 to-red-600/20 flex items-center justify-center mb-3 animate-float-delay">
                <svg
                  className="h-6 w-6 text-orange-500"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                </svg>
              </div>
              <p className="font-medium text-foreground text-sm">Multi-Timeframe</p>
              <p className="text-xs text-muted-foreground">1m to Monthly</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
