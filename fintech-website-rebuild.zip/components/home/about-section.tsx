import { Code2, Cpu, Rocket, Shield, Users, Zap } from "lucide-react"

export function AboutSection() {
  const features = [
    { icon: Code2, text: "100% Technology-driven platform" },
    { icon: Users, text: "Dedicated tech team with 15+ years experience" },
    { icon: Rocket, text: "High-performance trading algorithms" },
    { icon: Shield, text: "Transparent pricing with no hidden charges" },
    { icon: Zap, text: "24/7 automated system monitoring" },
    { icon: Cpu, text: "Real-time market data processing" },
  ]

  return (
    <section id="about" className="bg-muted/30 py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <span className="mb-4 inline-block text-sm font-medium text-accent">About Us</span>
            <h2 className="mb-6 text-3xl font-bold tracking-tight md:text-4xl text-balance">
              Your Trusted Partner in Trading Technology
            </h2>
            <p className="mb-6 text-muted-foreground leading-relaxed">
              TradeMetrix is a premium trading technology company dedicated to building powerful algorithmic trading
              software. Our team of expert developers and quants combines cutting-edge technology with market expertise
              to deliver professional-grade trading tools.
            </p>
            <p className="mb-8 text-muted-foreground leading-relaxed">
              With a focus on innovation and reliability, we provide comprehensive software solutions throughout your
              trading journey. Our proven technology has helped thousands of traders automate their strategies.
            </p>

            <div className="grid gap-3 sm:grid-cols-2">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent/10">
                    <feature.icon className="h-4 w-4 text-accent" />
                  </div>
                  <span className="text-sm">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square overflow-hidden rounded-2xl bg-muted">
              <img
                src="/professional-financial-advisor-team-meeting-in-mod.jpg"
                alt="TradeMetrix Technology Team"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 rounded-xl border border-border bg-card p-4 shadow-lg">
              <div className="text-3xl font-bold text-accent">15+</div>
              <div className="text-sm text-muted-foreground">Years in Tech</div>
            </div>
            <div className="absolute -right-6 -top-6 rounded-xl border border-border bg-card p-4 shadow-lg">
              <div className="text-3xl font-bold text-accent">10K+</div>
              <div className="text-sm text-muted-foreground">Active Users</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
