"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3, Briefcase, LineChart, PieChart, Shield, Zap, ArrowUpRight, Activity } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: LineChart,
      title: "Equity Trading",
      description: "Expert recommendations for cash market trades with detailed entry, target, and stop-loss levels.",
      color: "from-purple-500 to-purple-600",
      chartData: [30, 45, 35, 60, 50, 75, 65],
    },
    {
      icon: BarChart3,
      title: "Derivatives Advisory",
      description: "Strategic futures and options trading calls with comprehensive risk management.",
      color: "from-blue-500 to-blue-600",
      chartData: [40, 55, 45, 70, 55, 80, 70],
    },
    {
      icon: Briefcase,
      title: "Portfolio Management",
      description: "Customized portfolio building and rebalancing strategies based on your risk profile.",
      color: "from-indigo-500 to-indigo-600",
      chartData: [35, 50, 55, 65, 70, 75, 85],
    },
    {
      icon: PieChart,
      title: "Index Trading",
      description: "Nifty and Bank Nifty trading strategies for consistent returns in index derivatives.",
      color: "from-violet-500 to-violet-600",
      chartData: [45, 60, 50, 65, 55, 70, 75],
    },
    {
      icon: Shield,
      title: "Risk Management",
      description: "Position sizing, hedging strategies, and capital protection frameworks.",
      color: "from-purple-600 to-blue-500",
      chartData: [60, 55, 65, 60, 70, 65, 75],
    },
    {
      icon: Zap,
      title: "Intraday Calls",
      description: "Real-time intraday trading signals with quick entry and exit points for day traders.",
      color: "from-blue-600 to-indigo-500",
      chartData: [50, 70, 45, 80, 55, 85, 60],
    },
  ]

  return (
    <section id="services" className="py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <span className="mb-4 inline-block text-sm font-medium text-accent">Our Services</span>
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl text-balance">
            Comprehensive Trading Solutions
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            We offer a wide range of software services tailored to meet the diverse needs of traders and investors
            across different market segments.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => (
            <Card
              key={index}
              className="border-border/50 transition-all hover:border-accent/50 hover:shadow-md group overflow-hidden"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div
                    className={`mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br ${service.color} transition-transform group-hover:scale-110`}
                  >
                    <service.icon className="h-6 w-6 text-white" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <CardTitle className="text-lg">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="leading-relaxed mb-4">{service.description}</CardDescription>

                <div className="h-16 flex items-end gap-1 mt-4 pt-4 border-t border-border/50">
                  {service.chartData.map((value, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className={`w-full bg-gradient-to-t ${service.color} rounded-t opacity-30 group-hover:opacity-60 transition-all`}
                        style={{ height: `${value}%` }}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                  <span>Performance</span>
                  <span className="flex items-center gap-1 text-accent">
                    <Activity className="h-3 w-3" />
                    Live
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
