"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Play, TrendingUp, TrendingDown, BarChart3, Shield, RefreshCw } from "lucide-react"
import Link from "next/link"
import { useEffect, useState } from "react"

interface MarketData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  signal: "BUY" | "SELL" | "HOLD"
}

const initialMarketData: MarketData[] = [
  { symbol: "NIFTY", name: "NIFTY 50", price: 24850.35, change: 125.4, changePercent: 0.51, signal: "BUY" },
  { symbol: "BANKNIFTY", name: "BANK NIFTY", price: 53425.7, change: -89.3, changePercent: -0.17, signal: "HOLD" },
  { symbol: "SENSEX", name: "SENSEX", price: 81652.45, change: 342.15, changePercent: 0.42, signal: "BUY" },
  { symbol: "FINNIFTY", name: "FIN NIFTY", price: 23890.25, change: 78.5, changePercent: 0.33, signal: "BUY" },
]

export function HeroSection() {
  const [marketData, setMarketData] = useState<MarketData[]>(initialMarketData)
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [isLoading, setIsLoading] = useState(false)
  const [displayedIndices, setDisplayedIndices] = useState<[number, number]>([0, 1])

  const updateMarketData = () => {
    setIsLoading(true)
    setTimeout(() => {
      setMarketData((prev) =>
        prev.map((item) => {
          const randomChange = (Math.random() - 0.5) * 100
          const newPrice = item.price + randomChange
          const newChangePercent = (randomChange / item.price) * 100
          const newSignal: "BUY" | "SELL" | "HOLD" =
            newChangePercent > 0.3 ? "BUY" : newChangePercent < -0.3 ? "SELL" : "HOLD"

          return {
            ...item,
            price: Number.parseFloat(newPrice.toFixed(2)),
            change: Number.parseFloat(randomChange.toFixed(2)),
            changePercent: Number.parseFloat(newChangePercent.toFixed(2)),
            signal: newSignal,
          }
        }),
      )
      setLastUpdated(new Date())
      setIsLoading(false)
    }, 500)
  }

  // Auto-update every 10 seconds
  useEffect(() => {
    const interval = setInterval(updateMarketData, 10000)
    return () => clearInterval(interval)
  }, [])

  // Rotate displayed indices every 5 seconds
  useEffect(() => {
    const rotateInterval = setInterval(() => {
      setDisplayedIndices((prev) => {
        const next0 = (prev[0] + 2) % marketData.length
        const next1 = (prev[1] + 2) % marketData.length
        return [next0, next1]
      })
    }, 5000)
    return () => clearInterval(rotateInterval)
  }, [marketData.length])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price)
  }

  return (
    <section className="relative min-h-screen overflow-hidden bg-background pt-24">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.05)_1px,transparent_1px)] bg-[size:60px_60px]" />

      <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-purple-500/10 blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6 py-24 lg:px-8 lg:py-32">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/30 bg-purple-500/10 px-4 py-1.5 text-sm text-purple-600 mb-6">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-purple-500 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-purple-500" />
              </span>
              Live Market Data Connected
            </div>

            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
              Trade Smarter with <span className="text-gradient">AI-Driven Algo Trading</span> Software
            </h1>

            <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto lg:mx-0">
              Automate your trades with high-speed, accurate, and risk-managed trading algorithms. Built for Indian
              markets - NSE, BSE, Nifty & Bank Nifty.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/register">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-blue-500 text-white hover:from-purple-700 hover:to-blue-600 gap-2 w-full sm:w-auto"
                >
                  Start Free Trial
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/features">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-border text-foreground hover:bg-secondary gap-2 w-full sm:w-auto bg-transparent"
                >
                  <Play className="h-4 w-4" />
                  View Features
                </Button>
              </Link>
            </div>

            <div className="mt-12 flex items-center gap-8 justify-center lg:justify-start">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-purple-600" />
                <span className="text-sm text-muted-foreground">Bank-Level Security</span>
              </div>
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-500" />
                <span className="text-sm text-muted-foreground">Real-Time Analytics</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="glass rounded-2xl p-1 glow">
              <div className="rounded-xl bg-card p-6">
                {/* Trading Dashboard Preview */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-red-500" />
                    <div className="h-3 w-3 rounded-full bg-yellow-500" />
                    <div className="h-3 w-3 rounded-full bg-green-500" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">TradeMetrix Dashboard</span>
                    <button
                      onClick={updateMarketData}
                      className="p-1 rounded hover:bg-secondary/50 transition-colors"
                      title="Refresh prices"
                    >
                      <RefreshCw className={`h-3 w-3 text-muted-foreground ${isLoading ? "animate-spin" : ""}`} />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-lg bg-secondary/50 p-4">
                    <p className="text-sm text-muted-foreground">Today's P&L</p>
                    <p className="text-3xl font-bold text-foreground">+₹18,450</p>
                    <div className="flex items-center gap-2 mt-1">
                      <TrendingUp className="h-4 w-4 text-purple-600" />
                      <p className="text-sm text-purple-600">+2.34% from yesterday</p>
                    </div>
                  </div>

                  {/* Chart with updated gradient colors */}
                  <div className="h-40 rounded-lg bg-secondary/30 flex items-end justify-around px-4 pb-4">
                    {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 88].map((h, i) => (
                      <div
                        key={i}
                        className="w-4 rounded-t bg-gradient-to-t from-purple-500/50 to-blue-500"
                        style={{ height: `${h}%` }}
                      />
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {displayedIndices.map((index) => {
                      const data = marketData[index]
                      const isPositive = data.changePercent >= 0
                      return (
                        <div key={data.symbol} className="rounded-lg bg-secondary/50 p-3 transition-all duration-300">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-foreground">{data.name}</span>
                            <span
                              className={`text-xs px-1.5 py-0.5 rounded ${
                                data.signal === "BUY"
                                  ? "bg-purple-500/20 text-purple-600"
                                  : data.signal === "SELL"
                                    ? "bg-red-500/20 text-red-500"
                                    : "bg-yellow-500/20 text-yellow-600"
                              }`}
                            >
                              {data.signal}
                            </span>
                          </div>
                          <p className="text-lg font-bold text-foreground mt-1">{formatPrice(data.price)}</p>
                          <div className="flex items-center gap-1">
                            {isPositive ? (
                              <TrendingUp className="h-3 w-3 text-purple-600" />
                            ) : (
                              <TrendingDown className="h-3 w-3 text-red-500" />
                            )}
                            <p className={`text-xs ${isPositive ? "text-purple-600" : "text-red-500"}`}>
                              {isPositive ? "+" : ""}
                              {data.changePercent.toFixed(2)}%
                            </p>
                          </div>
                        </div>
                      )
                    })}
                  </div>

                  <div className="text-center">
                    <p className="text-xs text-muted-foreground">
                      Last updated: {lastUpdated.toLocaleTimeString("en-IN")} | Auto-refresh: 10s
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Cards with updated colors */}
            <div className="absolute -top-4 -right-4 glass rounded-lg p-3 animate-pulse">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-xs text-muted-foreground">Trade Executed</p>
                  <p className="text-sm font-medium text-foreground">+₹2,450</p>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-4 -left-4 glass rounded-lg p-3">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <Shield className="h-4 w-4 text-blue-500" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Risk Level</p>
                  <p className="text-sm font-medium text-purple-600">Low</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
