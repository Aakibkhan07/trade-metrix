"use client"

import { Star, Quote, TrendingUp, Shield, Zap } from "lucide-react"
import { useState, useEffect } from "react"

const testimonials = [
  {
    name: "Rajesh Kumar",
    role: "Day Trader",
    location: "Mumbai",
    avatar: "RK",
    rating: 5,
    text: "Trade Metrix Technologies has transformed my trading. The algo software executes trades faster than I ever could manually. The candlestick charts are incredibly accurate.",
    profit: "+₹2.4L",
    period: "Last Quarter",
  },
  {
    name: "Priya Sharma",
    role: "Options Trader",
    location: "Delhi",
    avatar: "PS",
    rating: 5,
    text: "The Bank Nifty strategies are phenomenal. Real-time alerts and automated execution have saved me countless hours. Best technology investment I've made.",
    profit: "+₹1.8L",
    period: "Last Month",
  },
  {
    name: "Amit Patel",
    role: "Swing Trader",
    location: "Ahmedabad",
    avatar: "AP",
    rating: 5,
    text: "Paper trading feature helped me test strategies without risk. Now running live with consistent results. The support team is very responsive.",
    profit: "+₹3.2L",
    period: "6 Months",
  },
  {
    name: "Sneha Reddy",
    role: "Portfolio Manager",
    location: "Bangalore",
    avatar: "SR",
    rating: 5,
    text: "Managing multiple client portfolios became seamless with Trade Metrix. The risk management tools and analytics dashboard are top-notch.",
    profit: "+₹5.6L",
    period: "Last Year",
  },
]

export function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-24 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
      <div className="absolute top-1/3 left-1/4 h-96 w-96 rounded-full bg-purple-500/5 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
            <Star className="h-4 w-4 icon-glow" />
            User Reviews
          </span>
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            Trusted by <span className="text-gradient">10,000+ Traders</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            See what our users say about their experience with Trade Metrix Technologies
          </p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto mb-12">
          <div className="glass rounded-xl p-4 text-center border border-primary/20">
            <div className="h-10 w-10 mx-auto rounded-lg bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center mb-2 icon-glow">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <p className="text-2xl font-bold text-foreground">4.9/5</p>
            <p className="text-xs text-muted-foreground">Average Rating</p>
          </div>
          <div className="glass rounded-xl p-4 text-center border border-primary/20">
            <div className="h-10 w-10 mx-auto rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center mb-2 icon-glow-blue">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <p className="text-2xl font-bold text-foreground">98%</p>
            <p className="text-xs text-muted-foreground">Satisfaction</p>
          </div>
          <div className="glass rounded-xl p-4 text-center border border-primary/20">
            <div className="h-10 w-10 mx-auto rounded-lg bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center mb-2">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <p className="text-2xl font-bold text-foreground">5K+</p>
            <p className="text-xs text-muted-foreground">Active Users</p>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`glass rounded-2xl p-6 border transition-all duration-500 ${
                index === activeIndex
                  ? "border-primary/50 bg-primary/5 scale-105 glow"
                  : "border-border hover:border-primary/30"
              }`}
            >
              <div className="flex items-start gap-3 mb-4">
                <div className="h-12 w-12 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-bold">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>

              <div className="flex gap-1 mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                ))}
              </div>

              <div className="relative mb-4">
                <Quote className="h-6 w-6 text-primary/20 absolute -top-2 -left-1" />
                <p className="text-sm text-muted-foreground pl-4">{testimonial.text}</p>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div>
                  <p className="text-lg font-bold text-green-500">{testimonial.profit}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.period}</p>
                </div>
                <div className="h-8 flex items-end gap-0.5">
                  {[30, 45, 35, 60, 50, 75, 65].map((h, i) => (
                    <div
                      key={i}
                      className="w-1.5 rounded-t bg-gradient-to-t from-purple-500/50 to-blue-500"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-2 mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`h-2 rounded-full transition-all ${
                index === activeIndex ? "w-8 bg-primary" : "w-2 bg-border hover:bg-primary/50"
              }`}
            />
          ))}
        </div>

        {/* Disclaimer */}
        <p className="text-center text-xs text-muted-foreground mt-8">
          * Individual results may vary. Trading involves risk. Past performance is not indicative of future results.
        </p>
      </div>
    </section>
  )
}
