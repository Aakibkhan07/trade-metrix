"use client"

import { useEffect, useState } from "react"
import { TrendingUp, TrendingDown, Activity } from "lucide-react"

interface TickerData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
}

const initialTickers: TickerData[] = [
  { symbol: "NIFTY", name: "NIFTY 50", price: 24850.35, change: 125.4, changePercent: 0.51 },
  { symbol: "BANKNIFTY", name: "BANK NIFTY", price: 53425.7, change: -89.3, changePercent: -0.17 },
  { symbol: "SENSEX", name: "SENSEX", price: 81652.45, change: 342.15, changePercent: 0.42 },
  { symbol: "FINNIFTY", name: "FIN NIFTY", price: 23890.25, change: 78.5, changePercent: 0.33 },
  { symbol: "RELIANCE", name: "RELIANCE", price: 2945.6, change: 32.45, changePercent: 1.11 },
  { symbol: "TCS", name: "TCS", price: 4125.8, change: -18.25, changePercent: -0.44 },
  { symbol: "INFY", name: "INFOSYS", price: 1876.35, change: 24.6, changePercent: 1.33 },
  { symbol: "HDFCBANK", name: "HDFC BANK", price: 1723.45, change: -8.9, changePercent: -0.51 },
]

export function LiveMarketTicker() {
  const [tickers, setTickers] = useState<TickerData[]>(initialTickers)

  useEffect(() => {
    const interval = setInterval(() => {
      setTickers((prev) =>
        prev.map((ticker) => {
          const changeAmount = (Math.random() - 0.5) * ticker.price * 0.002
          const newPrice = ticker.price + changeAmount
          const newChangePercent = ticker.changePercent + (Math.random() - 0.5) * 0.1

          return {
            ...ticker,
            price: Number(newPrice.toFixed(2)),
            change: Number((ticker.change + changeAmount).toFixed(2)),
            changePercent: Number(newChangePercent.toFixed(2)),
          }
        }),
      )
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="glass rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2 border-b border-border">
        <Activity className="h-4 w-4 text-primary icon-glow" />
        <span className="text-sm font-medium text-foreground">Live Market Ticker</span>
        <span className="relative flex h-2 w-2 ml-auto">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-500 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" />
        </span>
      </div>

      <div className="overflow-hidden">
        <div className="flex animate-scroll">
          {[...tickers, ...tickers].map((ticker, i) => (
            <div
              key={`${ticker.symbol}-${i}`}
              className="flex items-center gap-4 px-6 py-3 border-r border-border whitespace-nowrap"
            >
              <span className="font-medium text-foreground">{ticker.name}</span>
              <span className="text-foreground">₹{ticker.price.toLocaleString("en-IN")}</span>
              <span
                className={`flex items-center gap-1 ${ticker.changePercent >= 0 ? "text-green-500" : "text-red-500"}`}
              >
                {ticker.changePercent >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {ticker.changePercent >= 0 ? "+" : ""}
                {ticker.changePercent.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
