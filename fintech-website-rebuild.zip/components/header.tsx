"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, TrendingUp, ChevronDown, Home } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-blue-500">
            <TrendingUp className="h-5 w-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-semibold tracking-tight">Trade Metrix Technologies</span>
            <span className="text-[10px] text-muted-foreground -mt-1">Precision. Clarity. Control.</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          <Link
            href="/"
            className="flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <Home className="h-3.5 w-3.5" />
            Home
          </Link>

          <Link
            href="/about"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            About
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
              Products <ChevronDown className="h-3 w-3" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="center">
              <DropdownMenuItem asChild>
                <Link href="/features">Platform Features</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/algo-software">Algo Software</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/pricing">Pricing Plans</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
              Knowledge <ChevronDown className="h-3 w-3" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="center">
              <DropdownMenuItem asChild>
                <Link href="/market-knowledge">Market Knowledge</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/algo-knowledge">Algo Trading Guide</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link
            href="/#accuracy"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Performance
          </Link>
          <Link
            href="/contact"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Contact
          </Link>
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Button variant="ghost" asChild>
            <Link href="/login">Log In</Link>
          </Button>
          <Button
            asChild
            className="bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600"
          >
            <Link href="/register">Get Started</Link>
          </Button>
        </div>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-border lg:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="container mx-auto flex flex-col gap-4 px-4 py-4">
            <Link href="/" className="flex items-center gap-2 text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              <Home className="h-4 w-4" />
              Home
            </Link>
            <Link href="/about" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              About
            </Link>
            <div className="border-t border-border pt-2">
              <p className="mb-2 text-xs font-semibold text-muted-foreground uppercase">Products</p>
              <div className="flex flex-col gap-2 pl-2">
                <Link href="/features" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                  Platform Features
                </Link>
                <Link href="/algo-software" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                  Algo Software
                </Link>
                <Link href="/pricing" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                  Pricing Plans
                </Link>
              </div>
            </div>
            <div className="border-t border-border pt-2">
              <p className="mb-2 text-xs font-semibold text-muted-foreground uppercase">Knowledge</p>
              <div className="flex flex-col gap-2 pl-2">
                <Link href="/market-knowledge" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                  Market Knowledge
                </Link>
                <Link href="/algo-knowledge" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                  Algo Trading Guide
                </Link>
              </div>
            </div>
            <Link
              href="/#accuracy"
              className="text-sm font-medium border-t border-border pt-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Performance
            </Link>
            <Link href="/contact" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              Contact
            </Link>
            <div className="flex flex-col gap-2 border-t border-border pt-4">
              <Button variant="outline" asChild className="w-full bg-transparent">
                <Link href="/login">Log In</Link>
              </Button>
              <Button
                asChild
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600"
              >
                <Link href="/register">Get Started</Link>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
