import { Badge } from "@/components/ui/badge"

export function PricingHero() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-muted/30 py-20 md:py-28">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/5 via-transparent to-transparent" />

      <div className="container relative mx-auto px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center">
          <Badge variant="outline" className="mb-4">
            Algo Software Plans
          </Badge>

          <h1 className="mb-6 text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl text-balance">
            Choose Your <span className="text-accent">Trading</span> Plan
          </h1>

          <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
            Select the plan that fits your trading needs. All plans include access to our cloud-based algorithmic
            trading software with real-time execution.
          </p>
        </div>
      </div>
    </section>
  )
}
