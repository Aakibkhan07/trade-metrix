"use client"

import { Check, Star, Zap, Rocket, Crown, Building2, Activity } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const plans = [
  {
    name: "Monthly",
    price: "₹14,999",
    period: "/month",
    description: "Perfect for getting started with algo trading",
    strategies: 2,
    accuracy: "70-75%",
    icon: Zap,
    color: "from-purple-500 to-purple-600",
    chartData: [55, 60, 58, 65, 62, 70, 68, 72, 70, 75],
    features: [
      "2 Active Strategies",
      "Real-Time Signals",
      "One-Click Execution",
      "Smart Stoploss",
      "Basic Backtesting",
      "Email Support",
      "Single Broker Integration",
    ],
    popular: false,
  },
  {
    name: "Quarterly",
    price: "₹35,000",
    period: "/quarter",
    description: "For traders looking for more strategies",
    strategies: 4,
    accuracy: "75-80%",
    icon: Rocket,
    color: "from-blue-500 to-blue-600",
    chartData: [60, 65, 63, 70, 68, 75, 72, 78, 76, 80],
    features: [
      "4 Active Strategies",
      "Real-Time Signals",
      "One-Click Execution",
      "Smart Stoploss + Trailing SL",
      "Advanced Backtesting",
      "Priority Email Support",
      "3 Broker Integrations",
    ],
    popular: false,
  },
  {
    name: "Half-Yearly",
    price: "₹55,000",
    period: "/6 months",
    description: "Best value for serious traders",
    strategies: 8,
    accuracy: "80-85%",
    icon: Crown,
    color: "from-indigo-500 to-violet-500",
    chartData: [65, 70, 68, 75, 73, 80, 78, 83, 81, 85],
    features: [
      "8 Active Strategies",
      "Real-Time Signals",
      "One-Click Execution",
      "Smart Stoploss + Trailing SL",
      "Auto Hedging",
      "Full Backtesting Suite",
      "Strategy Builder Access",
      "Phone + Email Support",
      "5 Broker Integrations",
    ],
    popular: true,
  },
  {
    name: "Annual",
    price: "₹1,00,000",
    period: "/year",
    description: "Maximum strategies with premium support",
    strategies: 15,
    accuracy: "88%+",
    icon: Building2,
    color: "from-violet-500 to-purple-600",
    chartData: [70, 75, 78, 80, 82, 85, 84, 87, 86, 88],
    features: [
      "15 Active Strategies",
      "All Platform Features",
      "Smart Stoploss + Trailing SL",
      "Auto Hedging",
      "Paper + Live Trading",
      "Custom Strategy Development",
      "Dedicated Account Manager",
      "24/7 Priority Support",
      "Unlimited Broker Integrations",
    ],
    popular: false,
  },
]

export function PricingPlans() {
  return (
    <section className="py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`relative flex flex-col group overflow-hidden ${plan.popular ? "border-accent shadow-lg shadow-accent/10" : "border-border/50"}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-accent text-accent-foreground">
                    <Star className="mr-1 h-3 w-3" /> Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br ${plan.color} transition-transform group-hover:scale-110`}
                  >
                    <plan.icon className="h-5 w-5 text-white" />
                  </div>
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>

              <CardContent className="flex-1">
                <div className="mb-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>

                <div className="mb-4 flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {plan.strategies} Strategies
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {plan.accuracy} Accuracy*
                  </Badge>
                </div>

                <div className="mb-4 p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Expected Performance</span>
                    <span className="flex items-center gap-1 text-xs text-accent">
                      <Activity className="h-3 w-3" />
                      Live
                    </span>
                  </div>
                  <div className="h-12 flex items-end gap-0.5">
                    {plan.chartData.map((value, i) => (
                      <div
                        key={i}
                        className={`flex-1 bg-gradient-to-t ${plan.color} rounded-t opacity-50 group-hover:opacity-80 transition-opacity`}
                        style={{ height: `${value}%` }}
                      />
                    ))}
                  </div>
                </div>

                <ul className="space-y-2">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 shrink-0 text-success mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button className="w-full" variant={plan.popular ? "default" : "outline"} asChild>
                  <Link href="/register">Get Started</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Enterprise Plan */}
        <Card className="mt-8 border-border/50 bg-primary/5">
          <CardContent className="flex flex-col items-center justify-between gap-6 p-8 md:flex-row">
            <div className="text-center md:text-left">
              <div className="flex items-center gap-3 justify-center md:justify-start mb-2">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-purple-600 to-blue-500">
                  <Building2 className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold">Enterprise Plan</h3>
              </div>
              <p className="text-muted-foreground mb-2">
                For institutional traders and high-volume operations requiring custom solutions.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 md:justify-start">
                <Badge variant="outline">₹2,50,000+</Badge>
                <Badge variant="secondary">20++ Custom Strategies</Badge>
                <Badge variant="secondary">88%+ Accuracy*</Badge>
              </div>
            </div>
            <Button size="lg" asChild>
              <Link href="/contact">Contact Sales</Link>
            </Button>
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          * Accuracy ranges are indicative based on historical performance. Markets are subject to risk and returns are
          not guaranteed.
        </p>
      </div>
    </section>
  )
}
