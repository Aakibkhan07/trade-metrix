import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CTASection } from "@/components/cta-section"
import {
  Bot,
  Scan,
  Target,
  BarChart3,
  FileText,
  Wallet,
  TestTube,
  Zap,
  CheckCircle,
  Settings2,
  TrendingUp,
  AlertTriangle,
  LineChart,
  Server,
  Cpu,
  Database,
  Cloud,
} from "lucide-react"

const softwareFeatures = [
  {
    icon: Bot,
    title: "Strategy Automation System",
    description:
      "Convert any trading strategy into automated algorithms. Support for technical indicators, price action, and custom logic.",
    details: [
      "100+ built-in technical indicators",
      "Custom strategy creation",
      "Multi-timeframe analysis",
      "Condition-based triggers",
    ],
  },
  {
    icon: Scan,
    title: "Live Market Scanning",
    description: "Real-time scanning of NSE & BSE for trading opportunities based on your criteria.",
    details: [
      "Scan 1000+ stocks instantly",
      "Custom scanner creation",
      "Sector-wise filtering",
      "Volume & price alerts",
    ],
  },
  {
    icon: Target,
    title: "Auto Buy/Sell Triggers",
    description: "Automatic order execution when market conditions match your predefined rules.",
    details: ["Instant order placement", "Multiple order types", "Bracket orders support", "Time-based execution"],
  },
  {
    icon: BarChart3,
    title: "Profit/Loss Analytics Dashboard",
    description: "Comprehensive analytics to track and improve your trading performance.",
    details: ["Real-time P&L tracking", "Trade-wise breakdown", "Performance metrics", "Tax-ready reports"],
  },
  {
    icon: FileText,
    title: "Performance Reports",
    description: "Detailed reports with insights into your trading patterns and success rates.",
    details: ["Daily/weekly/monthly reports", "Win rate analysis", "Risk-adjusted returns", "Drawdown analysis"],
  },
  {
    icon: Wallet,
    title: "Multi-Broker Support",
    description: "Connect with 20+ Indian brokers through secure API integration.",
    details: ["Zerodha, Angel One, Upstox", "ICICI, HDFC, Kotak", "5paisa, Groww, Fyers", "Seamless switching"],
  },
]

const tradingModes = [
  {
    icon: TestTube,
    title: "Paper Trading Mode",
    description: "Test your strategies with virtual money in real market conditions without risking capital.",
    color: "text-blue-400",
    bgColor: "bg-blue-500/10",
  },
  {
    icon: Zap,
    title: "Live Trading Mode",
    description: "Execute real trades automatically through your connected broker account.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
]

const workflowSteps = [
  {
    step: 1,
    title: "Connect Your Broker",
    description: "Link your trading account using secure API keys",
    icon: Wallet,
  },
  {
    step: 2,
    title: "Choose or Create Strategy",
    description: "Select from 50+ pre-built strategies or create your own",
    icon: Settings2,
  },
  {
    step: 3,
    title: "Backtest & Optimize",
    description: "Test against historical data and fine-tune parameters",
    icon: LineChart,
  },
  {
    step: 4,
    title: "Paper Trade",
    description: "Validate in real market conditions with virtual money",
    icon: TestTube,
  },
  {
    step: 5,
    title: "Go Live",
    description: "Deploy your strategy with real capital",
    icon: TrendingUp,
  },
]

export const metadata = {
  title: "Algo Software | TradeMetrix - Algorithmic Trading Platform",
  description:
    "TradeMetrix Algo Software - strategy automation, live scanners, auto buy/sell, P&L analytics, multi-broker support, and AI-powered trading system.",
}

export default function AlgoSoftwarePage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 bg-background overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,212,170,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,212,170,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
        <div className="absolute top-1/3 right-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-6">
              Software Provider Only
            </span>
            <h1 className="text-4xl font-bold text-foreground sm:text-5xl lg:text-6xl text-balance">
              Advanced <span className="text-gradient">Algo Trading Software</span>
            </h1>
            <p className="mt-6 text-xl text-muted-foreground max-w-3xl mx-auto">
              Professional-grade algorithmic trading tools designed for Indian markets. Automate your strategies with
              powerful software for NSE, BSE, Nifty & Bank Nifty.
            </p>
            <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              <div className="glass rounded-xl p-4 border border-primary/20">
                <div className="text-2xl md:text-3xl font-bold text-primary mb-1">0.02s</div>
                <div className="text-xs md:text-sm text-muted-foreground">Avg Execution Time</div>
              </div>
              <div className="glass rounded-xl p-4 border border-primary/20">
                <div className="text-2xl md:text-3xl font-bold text-primary mb-1">60-88%</div>
                <div className="text-xs md:text-sm text-muted-foreground">Strategy Accuracy*</div>
              </div>
              <div className="glass rounded-xl p-4 border border-primary/20">
                <div className="text-2xl md:text-3xl font-bold text-primary mb-1">50+</div>
                <div className="text-xs md:text-sm text-muted-foreground">Pre-Built Strategies</div>
              </div>
              <div className="glass rounded-xl p-4 border border-primary/20">
                <div className="text-2xl md:text-3xl font-bold text-primary mb-1">24/7</div>
                <div className="text-xs md:text-sm text-muted-foreground">Market Monitoring</div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              *Based on historical backtesting. Past performance does not guarantee future results.
            </p>
          </div>
        </div>
      </section>

      {/* Trust Signals Section */}
      <section className="py-8 bg-card border-y border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-center text-muted-foreground text-sm font-medium uppercase tracking-wider mb-6">
            Connect With Any Indian Broker
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 items-center">
            <div className="flex items-center justify-center">
              <div className="glass rounded-lg px-6 py-4 border border-primary/20">
                <div className="text-primary font-bold text-lg">NSE</div>
                <div className="text-xs text-muted-foreground">Integrated</div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="glass rounded-lg px-6 py-4 border border-primary/20">
                <div className="text-primary font-bold text-lg">BSE</div>
                <div className="text-xs text-muted-foreground">Connected</div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="glass rounded-lg px-6 py-4 border border-primary/20">
                <div className="text-primary font-bold text-lg">20+</div>
                <div className="text-xs text-muted-foreground">Brokers Supported</div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="glass rounded-lg px-6 py-4 border border-primary/20">
                <div className="text-primary font-bold text-lg">Software</div>
                <div className="text-xs text-muted-foreground">Provider Only</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* System Architecture Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              Technology Architecture
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
              Powerful Algorithm <span className="text-gradient">Architecture</span>
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
              Built on cutting-edge technology stack with AI/ML capabilities, real-time data processing, and
              enterprise-grade security protocols.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* System Architecture Diagram */}
            <div className="glass rounded-2xl p-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">System Architecture</h3>
              <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg p-6 border border-border">
                <svg
                  className="w-full h-80"
                  viewBox="0 0 400 320"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-label="TradeMetrix system architecture diagram"
                >
                  {/* Market Data Layer */}
                  <rect x="20" y="20" width="360" height="55" rx="8" fill="currentColor" className="text-primary/10" />
                  <text x="200" y="42" textAnchor="middle" className="fill-primary text-sm font-semibold">
                    Market Data Layer
                  </text>
                  <text x="200" y="62" textAnchor="middle" className="fill-muted-foreground text-xs">
                    NSE/BSE Real-Time Feeds
                  </text>

                  {/* AI Processing Layer */}
                  <rect x="20" y="95" width="360" height="70" rx="8" fill="currentColor" className="text-primary/20" />
                  <text x="200" y="120" textAnchor="middle" className="fill-primary text-sm font-semibold">
                    AI Processing Engine
                  </text>
                  <text x="200" y="140" textAnchor="middle" className="fill-muted-foreground text-xs">
                    Machine Learning Models
                  </text>
                  <text x="200" y="155" textAnchor="middle" className="fill-muted-foreground text-xs">
                    Pattern Recognition - Risk Analysis
                  </text>

                  {/* Strategy & Risk Layer */}
                  <rect x="20" y="185" width="170" height="55" rx="8" fill="currentColor" className="text-primary/15" />
                  <text x="105" y="208" textAnchor="middle" className="fill-primary text-xs font-semibold">
                    Strategy Engine
                  </text>
                  <text x="105" y="228" textAnchor="middle" className="fill-muted-foreground text-[10px]">
                    50+ Algorithms
                  </text>

                  <rect
                    x="210"
                    y="185"
                    width="170"
                    height="55"
                    rx="8"
                    fill="currentColor"
                    className="text-yellow-500/15"
                  />
                  <text x="295" y="208" textAnchor="middle" className="fill-yellow-500 text-xs font-semibold">
                    Risk Management
                  </text>
                  <text x="295" y="228" textAnchor="middle" className="fill-muted-foreground text-[10px]">
                    Real-Time Monitoring
                  </text>

                  {/* Execution Layer */}
                  <rect
                    x="20"
                    y="260"
                    width="360"
                    height="40"
                    rx="8"
                    fill="currentColor"
                    className="text-foreground/10"
                  />
                  <text x="200" y="285" textAnchor="middle" className="fill-foreground text-xs font-semibold">
                    Order Execution Layer (0.02s)
                  </text>

                  {/* Arrows */}
                  <path
                    d="M200 75 L200 95"
                    stroke="currentColor"
                    className="stroke-primary"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  <path d="M150 165 L105 185" stroke="currentColor" className="stroke-primary" strokeWidth="2" />
                  <path d="M250 165 L295 185" stroke="currentColor" className="stroke-yellow-500" strokeWidth="2" />
                  <path
                    d="M105 240 L150 260"
                    stroke="currentColor"
                    className="stroke-muted-foreground"
                    strokeWidth="2"
                  />
                  <path
                    d="M295 240 L250 260"
                    stroke="currentColor"
                    className="stroke-muted-foreground"
                    strokeWidth="2"
                  />

                  <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                      <polygon points="0 0, 10 3, 0 6" fill="currentColor" className="fill-muted-foreground" />
                    </marker>
                  </defs>
                </svg>
              </div>
              <div className="mt-6 space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-foreground">Microservices Architecture</div>
                    <div className="text-sm text-muted-foreground">Scalable, fault-tolerant system design</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-foreground">Real-Time Data Pipeline</div>
                    <div className="text-sm text-muted-foreground">Sub-millisecond market data processing</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-foreground">Multi-Layer Security</div>
                    <div className="text-sm text-muted-foreground">Bank-grade encryption and authentication</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Technical Specifications */}
            <div className="glass rounded-2xl p-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">Technical Specifications</h3>
              <div className="space-y-6">
                {/* Performance Metrics */}
                <div>
                  <h4 className="text-lg font-semibold text-foreground mb-4">System Performance</h4>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-muted-foreground">Order Execution Speed</span>
                        <span className="font-semibold text-primary">0.02 seconds</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "98%" }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-muted-foreground">Data Processing Rate</span>
                        <span className="font-semibold text-primary">10,000 ticks/sec</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "95%" }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-muted-foreground">System Uptime</span>
                        <span className="font-semibold text-primary">99.9%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "99.9%" }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-muted-foreground">Latency (NSE/BSE)</span>
                        <span className="font-semibold text-primary">&lt; 5ms</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "97%" }} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Technology Stack */}
                <div>
                  <h4 className="text-lg font-semibold text-foreground mb-4">Technology Stack</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="glass rounded-lg p-3 border border-primary/20">
                      <div className="flex items-center gap-2 mb-1">
                        <Cpu className="h-4 w-4 text-primary" />
                        <span className="text-sm font-semibold text-foreground">AI/ML Engine</span>
                      </div>
                      <div className="text-xs text-muted-foreground">TensorFlow, PyTorch</div>
                    </div>
                    <div className="glass rounded-lg p-3 border border-primary/20">
                      <div className="flex items-center gap-2 mb-1">
                        <Server className="h-4 w-4 text-primary" />
                        <span className="text-sm font-semibold text-foreground">Data Processing</span>
                      </div>
                      <div className="text-xs text-muted-foreground">Apache Kafka, Redis</div>
                    </div>
                    <div className="glass rounded-lg p-3 border border-primary/20">
                      <div className="flex items-center gap-2 mb-1">
                        <Database className="h-4 w-4 text-primary" />
                        <span className="text-sm font-semibold text-foreground">Database</span>
                      </div>
                      <div className="text-xs text-muted-foreground">PostgreSQL, TimescaleDB</div>
                    </div>
                    <div className="glass rounded-lg p-3 border border-primary/20">
                      <div className="flex items-center gap-2 mb-1">
                        <Cloud className="h-4 w-4 text-primary" />
                        <span className="text-sm font-semibold text-foreground">Infrastructure</span>
                      </div>
                      <div className="text-xs text-muted-foreground">AWS, Docker, K8s</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-card border-y border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              How It Works
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">From Setup to Live Trading in 5 Steps</h2>
          </div>

          <div className="relative">
            {/* Connection Line */}
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-border hidden lg:block" />

            <div className="grid gap-8 lg:grid-cols-5">
              {workflowSteps.map((item, index) => (
                <div key={index} className="relative flex flex-col items-center text-center">
                  <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground mb-4">
                    <item.icon className="h-8 w-8" />
                  </div>
                  <span className="text-sm font-medium text-primary mb-2">Step {item.step}</span>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Software Features */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              Software Features
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl text-balance">
              Everything You Need for Automated Trading
            </h2>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {softwareFeatures.map((feature, index) => (
              <div
                key={index}
                className="group glass rounded-2xl p-8 transition-all hover:glow hover:border-primary/50"
              >
                <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <feature.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground mb-4">{feature.description}</p>
                <ul className="space-y-2">
                  {feature.details.map((detail, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trading Modes */}
      <section className="py-24 bg-card border-y border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              Trading Modes
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">Paper Trading & Live Trading</h2>
            <p className="mt-4 text-lg text-muted-foreground">Test before you invest, then go live with confidence</p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 max-w-4xl mx-auto">
            {tradingModes.map((mode, index) => (
              <div
                key={index}
                className="glass rounded-2xl p-8 border-2 border-transparent hover:border-primary/50 transition-all"
              >
                <div
                  className={`mb-6 inline-flex h-16 w-16 items-center justify-center rounded-xl ${mode.bgColor} ${mode.color}`}
                >
                  <mode.icon className="h-8 w-8" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-3">{mode.title}</h3>
                <p className="text-muted-foreground text-lg">{mode.description}</p>
              </div>
            ))}
          </div>

          {/* Risk Warning */}
          <div className="mt-12 glass rounded-xl p-6 max-w-3xl mx-auto border border-yellow-500/30 bg-yellow-500/5">
            <div className="flex gap-4">
              <AlertTriangle className="h-6 w-6 text-yellow-500 shrink-0" />
              <div>
                <h4 className="font-semibold text-foreground">Risk Disclosure</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Trading in securities market involves risk. Past performance is not indicative of future returns.
                  Please read all related documents carefully before trading. We recommend starting with paper trading.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Backtesting Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              Backtesting Engine
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
              Historical <span className="text-gradient">Strategy Testing</span>
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
              Test your strategies against 5+ years of historical market data. Analyze performance metrics before
              deploying with real capital.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Backtesting Features */}
            <div className="glass rounded-2xl p-8">
              <h3 className="text-xl font-semibold text-foreground mb-6">Backtesting Capabilities</h3>
              <div className="space-y-4">
                {[
                  { title: "5+ Years Historical Data", desc: "NSE & BSE tick-by-tick data from 2019 onwards" },
                  { title: "Multiple Timeframes", desc: "1-min, 5-min, 15-min, hourly, daily candles" },
                  { title: "Slippage Simulation", desc: "Realistic order execution with market impact modeling" },
                  { title: "Commission Calculation", desc: "Accurate brokerage and tax deduction simulation" },
                  { title: "Walk-Forward Analysis", desc: "Out-of-sample testing for strategy validation" },
                  { title: "Monte Carlo Simulation", desc: "Risk analysis with randomized scenario testing" },
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium text-foreground">{item.title}</div>
                      <div className="text-sm text-muted-foreground">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Metrics Available */}
            <div className="glass rounded-2xl p-8">
              <h3 className="text-xl font-semibold text-foreground mb-6">Analysis Metrics</h3>
              <p className="text-muted-foreground mb-6">
                Our backtesting engine provides comprehensive metrics to help you evaluate your strategy&apos;s
                historical behavior:
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  "Total Returns",
                  "Win/Loss Ratio",
                  "Sharpe Ratio",
                  "Sortino Ratio",
                  "Max Drawdown",
                  "Recovery Factor",
                  "Profit Factor",
                  "Avg Trade Duration",
                  "Total Trades",
                  "Consecutive Wins/Losses",
                  "Monthly Breakdown",
                  "Risk-Adjusted Returns",
                ].map((metric, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                    <span className="text-muted-foreground">{metric}</span>
                  </div>
                ))}
              </div>

              {/* Important Disclaimer */}
              <div className="mt-6 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 shrink-0" />
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">Important Notice</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      Backtesting results are based on historical data and do not guarantee future performance. Past
                      results are not indicative of future returns. All trading involves risk of loss.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="py-24 bg-card border-y border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              Dashboard Preview
            </span>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">Intuitive Trading Dashboard</h2>
          </div>

          <div className="glass rounded-2xl p-2 glow max-w-5xl mx-auto">
            <div className="rounded-xl bg-card p-6">
              {/* Window Controls */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-red-500" />
                  <div className="h-3 w-3 rounded-full bg-yellow-500" />
                  <div className="h-3 w-3 rounded-full bg-green-500" />
                </div>
                <span className="text-sm text-muted-foreground">TradeMetrix Pro Dashboard</span>
              </div>

              {/* Dashboard Grid */}
              <div className="grid gap-4 md:grid-cols-3">
                {/* Nifty 50 Live */}
                <div className="rounded-lg bg-secondary/50 p-4">
                  <p className="text-sm text-muted-foreground mb-2">NIFTY 50</p>
                  <p className="text-3xl font-bold text-foreground">19,425.35</p>
                  <p className="text-sm text-primary mt-1">+165.20 (+0.86%)</p>
                </div>

                {/* Bank Nifty Live */}
                <div className="rounded-lg bg-secondary/50 p-4">
                  <p className="text-sm text-muted-foreground mb-2">BANK NIFTY</p>
                  <p className="text-3xl font-bold text-foreground">44,892.15</p>
                  <p className="text-sm text-primary mt-1">+312.45 (+0.70%)</p>
                </div>

                {/* Active Strategies */}
                <div className="rounded-lg bg-secondary/50 p-4">
                  <p className="text-sm text-muted-foreground mb-2">Active Strategies</p>
                  <p className="text-3xl font-bold text-foreground">7</p>
                  <p className="text-sm text-muted-foreground mt-1">3 Options, 4 Equity</p>
                </div>
              </div>

              {/* Chart Area - Nifty Historical Chart */}
              <div className="mt-4 rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <span className="font-medium text-foreground">NIFTY 50 Historical</span>
                    <span className="text-sm text-muted-foreground">Live Chart</span>
                  </div>
                  <div className="flex gap-2">
                    {["1D", "1W", "1M", "3M", "1Y"].map((period) => (
                      <button
                        key={period}
                        className="px-3 py-1 rounded text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
                      >
                        {period}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="h-48 flex items-end justify-around">
                  {[65, 45, 70, 55, 80, 60, 75, 50, 85, 65, 90, 70, 95, 80, 88, 72, 92, 78, 96, 82].map((h, i) => (
                    <div
                      key={i}
                      className="w-3 rounded-t bg-gradient-to-t from-primary/50 to-primary transition-all hover:from-primary/70 hover:to-primary"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-4 text-center">
                  Historical market data shown for reference only. Not indicative of future performance.
                </p>
              </div>

              {/* Recent Trades */}
              <div className="mt-4 rounded-lg bg-secondary/30 p-4">
                <h4 className="font-medium text-foreground mb-3">Recent Trades</h4>
                <div className="space-y-2">
                  {[
                    { symbol: "RELIANCE", type: "BUY", qty: 50, price: "2,456.30", pnl: "+₹1,234", status: "success" },
                    {
                      symbol: "BANKNIFTY",
                      type: "SELL",
                      qty: 25,
                      price: "44,892.00",
                      pnl: "+₹5,670",
                      status: "success",
                    },
                    { symbol: "TCS", type: "BUY", qty: 30, price: "3,567.80", pnl: "-₹890", status: "loss" },
                  ].map((trade, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-secondary/50">
                      <div className="flex items-center gap-4">
                        <span
                          className={`text-xs px-2 py-0.5 rounded ${trade.type === "BUY" ? "bg-primary/20 text-primary" : "bg-red-500/20 text-red-400"}`}
                        >
                          {trade.type}
                        </span>
                        <span className="font-medium text-foreground">{trade.symbol}</span>
                        <span className="text-sm text-muted-foreground">
                          {trade.qty} qty @ ₹{trade.price}
                        </span>
                      </div>
                      <span className={trade.status === "success" ? "text-primary" : "text-red-400"}>{trade.pnl}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <CTASection />
      <Footer />
    </main>
  )
}
