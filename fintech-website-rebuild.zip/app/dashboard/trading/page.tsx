import { TradingDashboard } from "@/components/trading/trading-dashboard"

export default function TradingPage() {
  return <TradingDashboard />
}
