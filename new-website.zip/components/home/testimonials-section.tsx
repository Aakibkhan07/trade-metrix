"use client"

import { Star, Quote, CheckCircle2, ChevronLeft, ChevronRight } from "lucide-react"
import { useState, useRef } from "react"

const testimonials = [
  {
    name: "Vikram Mehta",
    role: "Full-Time Options Trader",
    location: "Mumbai",
    initials: "VM",
    rating: 5,
    text: "Switched to ScalperX 8 months ago. The automated stoploss saved me ₹45K in a single bad trade. Best decision for my capital preservation strategy.",
    strategy: "ScalperX",
    since: "8 months",
    verified: true,
  },
  {
    name: "Ananya Krishnamurthy",
    role: "Day Trader",
    location: "Bengaluru",
    initials: "AK",
    rating: 5,
    text: "Real-time signals are spot-on. Executed 240+ trades via platform and the accuracy on entries is remarkable. No more FOMO trading.",
    strategy: "OptiFlow",
    since: "5 months",
    verified: true,
  },
  {
    name: "Arun Patel",
    role: "Nifty 50 Specialist",
    location: "Delhi",
    initials: "AP",
    rating: 5,
    text: "Cut my losing trades by 60% using the trailing stoploss feature. The platform's discipline-first approach aligned perfectly with my trading goals.",
    strategy: "ScalperX",
    since: "10 months",
    verified: true,
  },
  {
    name: "Priya Sharma",
    role: "Portfolio Manager",
    location: "Hyderabad",
    initials: "PS",
    rating: 5,
    text: "Integrated TradeMetrix across all 5 brokers. Multi-broker execution saved us from missed setups. Institutional-grade execution at retail pricing.",
    strategy: "OptiFlow",
    since: "6 months",
    verified: true,
  },
  {
    name: "Rajesh Kumar",
    role: "Part-Time MCX Trader",
    location: "Pune",
    initials: "RK",
    rating: 5,
    text: "Trading crude oil and gold on MCX became consistent after using the platform. Auto-hedging reduced overnight gaps exposure significantly.",
    strategy: "ScalperX",
    since: "12 months",
    verified: true,
  },
  {
    name: "Sneha Desai",
    role: "Risk Management Consultant",
    location: "Ahmedabad",
    initials: "SD",
    rating: 5,
    text: "Position sizing recommendations are data-driven and precise. Helped my firm implement risk protocols 10x faster. Recommending to all traders.",
    strategy: "OptiFlow",
    since: "7 months",
    verified: true,
  },
]

export function TestimonialsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const sectionRef = useRef<HTMLElement>(null)

  // ... existing intersection observer code ...

  // ... existing auto-play effect ...

  const nextTestimonial = () => {
    setIsAutoPlaying(false)
    setActiveIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setIsAutoPlaying(false)
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  const featuredTestimonial = testimonials[activeIndex]

  const getInitialColor = (initials: string) => {
    const colors = [
      "bg-gradient-to-br from-blue-500 to-blue-600",
      "bg-gradient-to-br from-purple-500 to-purple-600",
      "bg-gradient-to-br from-cyan-500 to-cyan-600",
      "bg-gradient-to-br from-pink-500 to-pink-600",
      "bg-gradient-to-br from-green-500 to-green-600",
      "bg-gradient-to-br from-orange-500 to-orange-600",
    ]
    const hash = initials.charCodeAt(0) + initials.charCodeAt(1)
    return colors[hash % colors.length]
  }

  return (
    <section ref={sectionRef} className="py-16 md:py-24 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,180,180,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,180,180,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />

      <div className="absolute top-20 right-10 w-64 h-64 bg-primary/10 rounded-full blur-[100px] animate-float-slow" />
      <div className="absolute bottom-20 left-10 w-48 h-48 bg-accent/10 rounded-full blur-[80px] animate-float-reverse" />

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <div
          className={`text-center mb-10 md:mb-16 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-xs md:text-sm font-medium text-primary mb-4 animate-bounce-subtle border border-primary/20">
            <Star className="h-4 w-4" />
            Trusted by Traders
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Real Traders,{" "}
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Real Results
            </span>
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Join 5000+ traders who trust TradeMetrix with their trading automation
          </p>
        </div>

        <div
          className={`mb-12 transition-all duration-700 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <div className="relative bg-gradient-to-br from-card to-card/50 rounded-2xl border border-border p-6 md:p-8 overflow-hidden group hover:border-primary/30 transition-all duration-500">
            {/* Glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            <div className="relative flex flex-col md:flex-row items-center gap-6">
              <div className="relative">
                <div
                  className={`w-24 h-24 ${getInitialColor(featuredTestimonial.initials)} rounded-full flex items-center justify-center border-4 border-background shadow-lg`}
                >
                  <span className="text-3xl font-bold text-white">{featuredTestimonial.initials}</span>
                </div>
                {featuredTestimonial.verified && (
                  <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-1">
                    <CheckCircle2 className="h-4 w-4 text-white" />
                  </div>
                )}
              </div>

              <div className="flex-1 text-center md:text-left">
                <Quote className="h-8 w-8 text-primary/20 mb-2 mx-auto md:mx-0" />
                <p className="text-lg md:text-xl text-foreground font-medium mb-4 leading-relaxed">
                  "{featuredTestimonial.text}"
                </p>

                <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
                  <div>
                    <p className="font-bold text-foreground">{featuredTestimonial.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {featuredTestimonial.role}, {featuredTestimonial.location}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 md:ml-auto">
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                      {featuredTestimonial.strategy}
                    </span>
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">
                      Since {featuredTestimonial.since}
                    </span>
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 transition-all duration-300 ${i < featuredTestimonial.rating ? "fill-yellow-500 text-yellow-500 animate-bounce-subtle" : "text-muted-foreground/30"}`}
                          style={{ animationDelay: `${i * 100}ms` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-6">
              <button
                onClick={prevTestimonial}
                className="p-2 rounded-full bg-secondary hover:bg-primary/20 transition-colors"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>

              <div className="flex gap-2">
                {testimonials.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setIsAutoPlaying(false)
                      setActiveIndex(idx)
                    }}
                    className={`h-2 rounded-full transition-all duration-300 ${idx === activeIndex ? "w-8 bg-primary" : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50"}`}
                  />
                ))}
              </div>

              <button
                onClick={nextTestimonial}
                className="p-2 rounded-full bg-secondary hover:bg-primary/20 transition-colors"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid gap-3 md:gap-4 grid-cols-2 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              onClick={() => {
                setIsAutoPlaying(false)
                setActiveIndex(index)
              }}
              className={`group cursor-pointer bg-card rounded-xl p-3 md:p-4 border transition-all duration-500 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/10 ${index === activeIndex ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"} ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
              style={{ transitionDelay: `${200 + index * 50}ms` }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div
                  className={`w-8 h-8 ${getInitialColor(testimonial.initials)} rounded-full flex items-center justify-center flex-shrink-0 border border-background`}
                >
                  <span className="text-xs font-bold text-white">{testimonial.initials}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-xs text-foreground truncate">{testimonial.name}</p>
                  <div className="flex gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-2.5 w-2.5 ${i < testimonial.rating ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground/30"}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-[10px] md:text-xs text-muted-foreground line-clamp-2 group-hover:text-foreground/70 transition-colors">
                "{testimonial.text}"
              </p>
            </div>
          ))}
        </div>

        <div
          className={`mt-8 p-3 md:p-4 rounded-xl bg-muted/30 border border-border transition-all duration-700 delay-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <p className="text-center text-[10px] md:text-xs text-muted-foreground">
            <strong>Disclaimer:</strong> Results shown are from verified users and may not be typical. Trading involves
            risk. We provide strategies, not tips or advisory services.
          </p>
        </div>
      </div>
    </section>
  )
}
