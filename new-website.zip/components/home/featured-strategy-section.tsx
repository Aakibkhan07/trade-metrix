"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowRight, TrendingUp, CheckCircle, Zap, Target, Shield } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function FeaturedStrategySection() {
  const [isVisible, setIsVisible] = useState(false)
  const [stats, setStats] = useState({ scalperTrades: 0, optiFlowTrades: 0 })
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          let scalperCount = 0
          let optiFlowCount = 0

          const interval = setInterval(() => {
            if (scalperCount < 847) scalperCount += 28
            if (optiFlowCount < 634) optiFlowCount += 21

            setStats({
              scalperTrades: Math.min(scalperCount, 847),
              optiFlowTrades: Math.min(optiFlowCount, 634),
            })

            if (scalperCount >= 847 && optiFlowCount >= 634) {
              clearInterval(interval)
            }
          }, 20)

          return () => clearInterval(interval)
        }
      },
      { threshold: 0.3 },
    )

    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <div
      ref={sectionRef}
      className="py-16 md:py-32 relative overflow-hidden bg-gradient-to-b from-background via-primary/5 to-background"
    >
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] animate-float-slow" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[120px] animate-float-reverse" />

      <div className="container mx-auto px-4 md:px-6 relative">
        {/* Header */}
        <div
          className={`text-center mb-12 md:mb-16 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 mb-4 border border-primary/20 animate-bounce-subtle">
            <Zap className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Our Most Powerful Strategies</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4 leading-tight">
            Meet{" "}
            <span className="relative">
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient-x">
                ScalperX
              </span>
              <span className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent rounded-full" />
            </span>
            {" & "}
            <span className="relative">
              <span className="bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent animate-gradient-x">
                OptiFlow
              </span>
              <span className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-accent to-primary rounded-full" />
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mt-6">
            Specialized strategies designed for different markets. Trade equities, indices, and commodities with precision-engineered algorithms.
          </p>
        </div>

        {/* Equity Market Section */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Equity & Index Options</h3>
            <p className="text-muted-foreground">Professional-grade strategies for NSE index and stock options trading</p>
          </div>
          
          {/* Main content grid */}
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
            {/* Left: ScalperX Card */}
            <div
              className={`transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"}`}
            >
              <div className="relative bg-gradient-to-br from-card to-card/50 rounded-2xl border border-primary/30 p-8 overflow-hidden group hover:border-primary/50 transition-all duration-300">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent p-0.5">
                          <div className="w-full h-full bg-card rounded-[10px] flex items-center justify-center">
                            <Target className="h-6 w-6 text-primary" />
                          </div>
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-foreground">ScalperX</h3>
                          <p className="text-xs text-muted-foreground">Index Options Specialist</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 rounded-full bg-success/10 px-3 py-1.5 border border-success/30">
                      <span className="relative flex h-2 w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-success" />
                      </span>
                      <span className="text-xs font-medium text-success">Active</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                    Specialized in capturing quick intra-day moves in NIFTY and BANK NIFTY index options. Also works for MCX crude oil and energy futures. Executes multiple scalp trades daily with precision entry and exit points.
                  </p>

                  <div className="space-y-3 mb-8 pb-8 border-b border-border/50">
                    {[
                      { icon: Zap, text: "Ultra-fast execution", subtext: "Entry to exit in milliseconds" },
                      { icon: Target, text: "80%+ accuracy signals", subtext: "Based on backtested performance" },
                      { icon: TrendingUp, text: "Market-adaptive strategy", subtext: "Adjusts to market volatility" },
                    ].map((feature, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 group/item cursor-default hover:bg-primary/5 p-2 rounded-lg transition-all duration-300"
                      >
                        <feature.icon className="h-5 w-5 text-primary mt-0.5 flex-shrink-0 group-hover/item:scale-110 transition-transform" />
                        <div>
                          <p className="text-sm font-medium text-foreground">{feature.text}</p>
                          <p className="text-xs text-muted-foreground">{feature.subtext}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Stats showcase */}
                  <div className="text-center p-4 rounded-lg bg-success/10 border border-success/20 group/stat hover:border-success/40 hover:bg-success/15 transition-all duration-300">
                    <p className="text-3xl font-bold text-success">{stats.scalperTrades}</p>
                    <p className="text-xs text-muted-foreground mt-1">Trades Executed YTD</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: OptiFlow Card */}
            <div
              className={`transition-all duration-700 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
            >
              <div className="relative bg-gradient-to-br from-card to-card/50 rounded-2xl border border-accent/30 p-8 overflow-hidden group hover:border-accent/50 transition-all duration-300">
                <div className="absolute -inset-1 bg-gradient-to-r from-accent/20 via-primary/20 to-accent/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary p-0.5">
                          <div className="w-full h-full bg-card rounded-[10px] flex items-center justify-center">
                            <TrendingUp className="h-6 w-6 text-accent" />
                          </div>
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-foreground">OptiFlow</h3>
                          <p className="text-xs text-muted-foreground">Stock Options Expert</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 rounded-full bg-success/10 px-3 py-1.5 border border-success/30">
                      <span className="relative flex h-2 w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-success" />
                      </span>
                      <span className="text-xs font-medium text-success">Active</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                    Optimized for individual stock options trading and MCX precious metals (gold/silver). Focuses on directional plays and premium selling strategies across markets.
                  </p>

                  <div className="space-y-3 mb-8 pb-8 border-b border-border/50">
                    {[
                      { icon: TrendingUp, text: "Multi-stock coverage", subtext: "Trades 20+ actively monitored stocks" },
                      { icon: Target, text: "Directional precision", subtext: "Call and put strategies combined" },
                      { icon: Zap, text: "Premium optimization", subtext: "Captures volatility efficiently" },
                    ].map((feature, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 group/item cursor-default hover:bg-accent/5 p-2 rounded-lg transition-all duration-300"
                      >
                        <feature.icon className="h-5 w-5 text-accent mt-0.5 flex-shrink-0 group-hover/item:scale-110 transition-transform" />
                        <div>
                          <p className="text-sm font-medium text-foreground">{feature.text}</p>
                          <p className="text-xs text-muted-foreground">{feature.subtext}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Stats showcase */}
                  <div className="text-center p-4 rounded-lg bg-accent/10 border border-accent/20 group/stat hover:border-accent/40 hover:bg-accent/15 transition-all duration-300">
                    <p className="text-3xl font-bold text-accent">{stats.optiFlowTrades}</p>
                    <p className="text-xs text-muted-foreground mt-1">Trades Executed YTD</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features section below both strategies */}
        <div className="mt-16 max-w-4xl mx-auto">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-8 text-center">Why Professional Traders Choose Trade Metrix</h3>

          <div className="grid md:grid-cols-3 gap-4">
            {[
              { title: "Proven Track Record", desc: "Backtested across multiple market cycles", icon: TrendingUp },
              { title: "Automated Risk Management", desc: "Built-in stop-loss and take-profit levels", icon: Shield },
              { title: "Real-time Signals", desc: "Instant notifications on mobile and desktop", icon: Zap },
              { title: "Full Transparency", desc: "See every trade executed with complete details", icon: CheckCircle },
              { title: "24/7 Execution", desc: "Strategies work while you sleep", icon: TrendingUp },
              { title: "Strategy Customization", desc: "Adjust parameters to match your style", icon: Target },
            ].map((benefit, idx) => (
              <div
                key={idx}
                className={`flex flex-col items-center text-center p-6 rounded-xl bg-card/50 border border-border hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 group/benefit ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                style={{ transitionDelay: `${400 + idx * 80}ms` }}
              >
                <benefit.icon className="h-8 w-8 text-primary mb-3" />
                <p className="font-medium text-foreground text-sm">{benefit.title}</p>
                <p className="text-xs text-muted-foreground mt-2">{benefit.desc}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mt-12 justify-center">
            <Link href="/register">
              <Button size="lg" className="rounded-full group hover:scale-105 transition-transform">
                Get Started with ScalperX
                <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/features">
              <Button
                size="lg"
                variant="outline"
                className="rounded-full group hover:bg-primary/10 transition-all bg-transparent"
              >
                <Shield className="h-4 w-4 mr-2" />
                Explore All Strategies
              </Button>
            </Link>
          </div>

          <p className="text-xs text-muted-foreground mt-8 text-center">
            *All performance metrics are based on historical backtesting. Individual results may vary. No strategy guarantees profits.
          </p>
        </div>
      </div>
    </div>
  )
}
